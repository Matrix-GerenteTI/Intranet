function createTemplateConsultaParte(element) {
    //console.log(element)
    valueToAppend = `<tr style="cursor:pointer">
                        <td>${element.CODIGOARTICULO}</td>
                        <td>${element.DESCRIPCION}</td>
                        <td>${element.PVP1}</td>
                        <td>${element.PVP2}</td>
                        <td>${element.PVP3}</td>
                        <td>${element.PVP4}</td>
                        `
    if(!$.isEmptyObject(element.PVP5) && !$.isEmptyObject(element.PVP10)){
        valueToAppend += `<td>${element.PVP5}</td>
                        <td>${element.PVP10}</td>`
    }
                        
    valueToAppend += `
                      <td style="text-align: center;">${element.EXISTOTAL}</td>
                      <td style="text-align: center;">${element.ALMACEN}</td>
					</tr>`

	return valueToAppend;
}

$("#searchProduct").click(function(e){
    e.preventDefault();
	$.get("/intranet/productosColision", {
            codproduct: $("#codproduct").val(),
            descripcion: $("#descripProduct").val()
		},
		function (data) {
            
			$("#tbodyConsultaParte").html("")
            let valueToAppend = ""
            
            if ($.isEmptyObject(data) ) {
                alert("LA PIEZA BUSCADA NO PERTENECE A LA FAMILIA COLISION. REINTENTA")
            }
            else{
                $.each(data, function (i) {
                    valueToAppend += createTemplateConsultaParte(data[i]);
                });           
            }
            
            $("#tbodyConsultaParte").append(valueToAppend)
            
		},
		"json"
	);	
});