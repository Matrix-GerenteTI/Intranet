<?php

require_once $_SERVER['DOCUMENT_ROOT']."/intranet/modelos/nomina/incidencias.php";

class DeduccionesController 
{
    
    protected $modeloIncidencia;

    public function __construct()
    {
        $this->modeloIncidencia = new Incidencias;
    }

    public function getCatalogo()
    {
        return $this->modeloIncidencia->getCatalogoDeducciones();
    }
}
